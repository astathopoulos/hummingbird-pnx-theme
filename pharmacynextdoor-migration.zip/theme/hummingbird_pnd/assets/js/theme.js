/**
 * PharmacyNextDoor — Hummingbird child theme
 * Theme behaviour (compiled · vanilla JS · no jQuery).
 *
 * Scope note: cart, quantity, wishlist, facets, slider, menu and search
 * behaviours are owned by PrestaShop core + official modules and the parent
 * Hummingbird TS components — they are NOT re-implemented here. This file only
 * adds the genuinely theme-specific progressive enhancements.
 *
 * Currently: password-reveal toggle on auth forms.
 * Enable by adding data-ps-component="password-reveal" to a password field
 * wrapper (see README — optional form-fields.tpl override).
 */
(function () {
  "use strict";

  var SELECTORS = {
    field: '[data-ps-component="password-reveal"]',
    toggle: '[data-ps-action="toggle-password"]',
  };

  var EYE =
    '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
  var EYE_OFF =
    '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M9.9 4.2A10.9 10.9 0 0 1 12 4c6.5 0 10 7 10 7a18 18 0 0 1-3.2 4M6.2 6.2A18 18 0 0 0 2 11s3.5 7 10 7a10.8 10.8 0 0 0 4-.8"/><path d="m3 3 18 18M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';

  /** Inject the toggle button into a password-reveal field (idempotent). */
  function enhance(field) {
    if (field.getAttribute("data-ps-state") === "ready") return;
    var input = field.querySelector('input[type="password"]');
    if (!input) return;

    field.setAttribute("data-ps-state", "ready");
    field.classList.add("pwd-wrap");

    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "pwd-toggle";
    btn.setAttribute("data-ps-action", "toggle-password");
    btn.setAttribute("aria-label", "Εμφάνιση κωδικού");
    btn.innerHTML = EYE;
    field.appendChild(btn);
  }

  function enhanceAll(root) {
    (root || document).querySelectorAll(SELECTORS.field).forEach(enhance);
  }

  /* Event delegation — single listener for every toggle, now and after Ajax. */
  document.addEventListener("click", function (event) {
    var target = event.target;
    var btn = target && target.closest ? target.closest(SELECTORS.toggle) : null;
    if (!btn) return;

    var field = btn.closest(SELECTORS.field);
    var input = field && field.querySelector('input');
    if (!input) return;

    var reveal = input.type === "password";
    input.type = reveal ? "text" : "password";
    btn.innerHTML = reveal ? EYE_OFF : EYE;
    btn.setAttribute("aria-label", reveal ? "Απόκρυψη κωδικού" : "Εμφάνιση κωδικού");
  });

  /* Initial pass. */
  if (document.readyState !== "loading") {
    enhanceAll();
  } else {
    document.addEventListener("DOMContentLoaded", function () {
      enhanceAll();
    });
  }

  /* Re-enhance fields injected by PrestaShop Ajax (checkout, account, etc.). */
  if (typeof MutationObserver !== "undefined") {
    new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        mutation.addedNodes.forEach(function (node) {
          if (node.nodeType !== 1) return;
          if (node.matches && node.matches(SELECTORS.field)) enhance(node);
          enhanceAll(node);
        });
      });
    }).observe(document.documentElement, { childList: true, subtree: true });
  }
})();
