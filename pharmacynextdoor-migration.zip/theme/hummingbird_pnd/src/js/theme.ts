/**
 * PharmacyNextDoor — Hummingbird child theme
 * Theme behaviour (source · TypeScript).
 *
 * Follows Hummingbird's JS conventions (CONTEXT.md):
 *   · no jQuery — modern DOM APIs only
 *   · JS binds to [data-ps-*] attributes, never to CSS classes
 *   · event delegation + MutationObserver for Ajax-injected DOM
 *   · strict typing, no `any`
 *
 * Cart / quantity / wishlist / facets / slider / menu / search are core +
 * module + parent-theme concerns and are intentionally NOT handled here.
 */

interface RevealSelectors {
  field: string;
  toggle: string;
}

const SELECTORS: RevealSelectors = {
  field: '[data-ps-component="password-reveal"]',
  toggle: '[data-ps-action="toggle-password"]',
};

const EYE =
  '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
const EYE_OFF =
  '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M9.9 4.2A10.9 10.9 0 0 1 12 4c6.5 0 10 7 10 7a18 18 0 0 1-3.2 4M6.2 6.2A18 18 0 0 0 2 11s3.5 7 10 7a10.8 10.8 0 0 0 4-.8"/><path d="m3 3 18 18M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';

/** Inject a reveal button into a password field wrapper (idempotent). */
function enhance(field: HTMLElement): void {
  if (field.dataset.psState === "ready") return;
  const input = field.querySelector<HTMLInputElement>('input[type="password"]');
  if (!input) return;

  field.dataset.psState = "ready";
  field.classList.add("pwd-wrap");

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "pwd-toggle";
  btn.dataset.psAction = "toggle-password";
  btn.setAttribute("aria-label", "Εμφάνιση κωδικού");
  btn.innerHTML = EYE;
  field.appendChild(btn);
}

function enhanceAll(root: ParentNode = document): void {
  root.querySelectorAll<HTMLElement>(SELECTORS.field).forEach(enhance);
}

document.addEventListener("click", (event: MouseEvent): void => {
  const target = event.target as HTMLElement | null;
  const btn = target?.closest<HTMLButtonElement>(SELECTORS.toggle);
  if (!btn) return;

  const field = btn.closest<HTMLElement>(SELECTORS.field);
  const input = field?.querySelector<HTMLInputElement>("input");
  if (!input) return;

  const reveal = input.type === "password";
  input.type = reveal ? "text" : "password";
  btn.innerHTML = reveal ? EYE_OFF : EYE;
  btn.setAttribute("aria-label", reveal ? "Απόκρυψη κωδικού" : "Εμφάνιση κωδικού");
});

if (document.readyState !== "loading") {
  enhanceAll();
} else {
  document.addEventListener("DOMContentLoaded", () => enhanceAll());
}

new MutationObserver((mutations: MutationRecord[]): void => {
  mutations.forEach((mutation) => {
    mutation.addedNodes.forEach((node) => {
      if (!(node instanceof HTMLElement)) return;
      if (node.matches(SELECTORS.field)) enhance(node);
      enhanceAll(node);
    });
  });
}).observe(document.documentElement, { childList: true, subtree: true });
