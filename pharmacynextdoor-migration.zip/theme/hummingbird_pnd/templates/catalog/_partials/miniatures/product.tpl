{**
 * PharmacyNextDoor — Hummingbird child theme
 * Product miniature override.
 *
 * The only structural change versus the parent card is a manufacturer/brand
 * line printed above the product name (matches the PND card design). Everything
 * else — image, flags, prices, reviews hook, quantity + add-to-cart — is
 * inherited untouched via Smarty block inheritance, so the card stays in sync
 * with future Hummingbird updates.
 *
 * NOTE: the wishlist heart shown in the PND design is provided by the official
 * `blockwishlist` module (it injects its button into the miniature via hook).
 * Enable that module rather than hard-coding the button here.
 *}
{extends file='parent:catalog/_partials/miniatures/product.tpl'}

{block name='product_name' prepend}
  {if isset($product.manufacturer_name) && $product.manufacturer_name}
    <div class="product-miniature__brand">{$product.manufacturer_name|escape:'html':'UTF-8'}</div>
  {/if}
{/block}
